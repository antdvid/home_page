var searchData=
[
  ['utility_20function',['Utility Function',['../d2/d1e/group__uapi.html',1,'']]],
  ['uapi_2eh',['uapi.h',['../df/de7/uapi_8h.html',1,'']]]
];
