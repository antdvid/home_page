var searchData=
[
  ['sampling_20functions',['Sampling Functions',['../d2/df1/group__SAMPLE.html',1,'']]],
  ['surface_20functions',['SURFACE Functions',['../d8/dbe/group__SURFACE.html',1,'']]]
];
