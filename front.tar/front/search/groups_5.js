var searchData=
[
  ['utility_20function',['Utility Function',['../d2/d1e/group__uapi.html',1,'']]]
];
